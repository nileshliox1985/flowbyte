package boot.app;

import java.util.Arrays;
import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
import org.springframework.web.servlet.resource.ResourceHttpRequestHandler;

/**
 * @author Ved
 *
 */
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {
	
	
	
	@Autowired
	BCryptPasswordEncoder passwordEncoder;
	
	@Bean
    @Override
    protected UserDetailsService userDetailsService() {
        UserDetails user1 = User
                .withUsername("patil")
                .password("$2a$10$PIe5Z/ZkAUp13kRhCmBfru7LLQx2BRZL2wToL//vG2OlbLly/LrQS")
                .roles("USER")
                .build();
        UserDetails user2 = User
                .withUsername("admin")
                .password("$2a$10$dKACG16LWMp8r4p2Y8l/TuSzDNZ7Xcrt0cWF8Du8SrncuZSIRCkO6")
                .roles("ADMIN")
                .build();      
         
        return new InMemoryUserDetailsManager(user1, user2);
    }
	

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		 http.authorizeRequests()
	        .antMatchers("/", "/login","/register","/forgotpassword","/logout","/index","/error","/font/**","/info**","/contact**").permitAll()
	        .antMatchers(HttpMethod.GET,"/resources/**", "/static/**", "/css/**", "/js/**","/vendor/**", "/images/**","/vendor**").permitAll()
	        .mvcMatchers("/").hasRole("ADMIN")
	        .anyRequest()
	        .authenticated().and().formLogin()
	        .loginPage("/login")
	        .loginProcessingUrl("/login")
			.failureUrl("/login?error=true")
			.defaultSuccessUrl("/dashboard")
	        .usernameParameter("userName").passwordParameter("password")
	        .and().logout()
			.logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
			.logoutSuccessUrl("/").and().exceptionHandling()
	        .and().exceptionHandling().accessDeniedPage("/access-denied");
		 
	} 
	
	@Override
	public void configure(WebSecurity web) throws Exception {
	    web
	       .ignoring()
	       .antMatchers("/resources/**", "/static/**", "/css/**", "/js/**", "/images/**");
	}
	
	@Bean
	public SimpleUrlHandlerMapping faviconHandlerMapping() {
		SimpleUrlHandlerMapping mapping = new SimpleUrlHandlerMapping();
		mapping.setOrder(Integer.MIN_VALUE);
		mapping.setUrlMap(Collections.singletonMap("favicon.ico", faviconRequestHandler()));
		return mapping;
	}

	@Bean
	protected ResourceHttpRequestHandler faviconRequestHandler() {
		ResourceHttpRequestHandler requestHandler = new ResourceHttpRequestHandler();
		requestHandler.setLocations(Arrays.<Resource>asList(new ClassPathResource("/")));
		return requestHandler;
	}

	
	
}
