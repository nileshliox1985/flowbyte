package boot.app;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration.Dynamic;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

/**
 * @author Ved
 *
 */
public class WebAppInitializer implements WebApplicationInitializer {
	public void onStartup(ServletContext servletContext) throws ServletException {
		AnnotationConfigWebApplicationContext ctx = new AnnotationConfigWebApplicationContext();
		ctx.register(BananaApplication.class);
		ctx.setServletContext(servletContext);
		DispatcherServlet ds = new DispatcherServlet(ctx);
		Dynamic dynamic = servletContext.addServlet("dispatcher",ds);
		dynamic.addMapping("/");
		dynamic.setLoadOnStartup(1);
	}
}
