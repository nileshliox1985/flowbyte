/**
 * 
 */
package boot.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @author Ved
 *
 */
@Controller
public class DashBoardController {
	
	@RequestMapping(value = "/dashboard", method = RequestMethod.GET)
    String dashboard(Model model) throws Exception{
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		model.addAttribute("totalFertNpk", 10);
		model.addAttribute("totalFarms",  20);
		model.addAttribute("totalSow",  30);
		model.addAttribute("totalFert",  40);
		model.addAttribute("totalSpray",  50);
		model.addAttribute("totalDrip",  560);
		model.addAttribute("totalSupport",  70);
		model.addAttribute("loggedUser",  SecurityContextHolder.getContext().getAuthentication().getName());
		return "dashboard";
    }
	
	@RequestMapping(value={"/help"}, method = RequestMethod.GET)
	String help(Model model){
		return "help";
	}
}
